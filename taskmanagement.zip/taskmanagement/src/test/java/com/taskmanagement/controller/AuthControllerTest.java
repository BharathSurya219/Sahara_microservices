package com.taskmanagement.controller;

import com.taskmanagement.entity.User;
import com.taskmanagement.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@WebMvcTest(AuthController.class)
@WithMockUser // Bypasses Spring Security 401
public class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private UserService userService;

    private User user;

    @BeforeEach
    void setup() {
        user = new User();
        user.setUsername("john");
        user.setPassword("password123");
    }

    @Test
    void testHomeRedirectsToLogin() throws Exception {
        mockMvc.perform(get("/"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    void testLoginPageWithoutParams() throws Exception {
        mockMvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("login"))
                .andExpect(model().attributeDoesNotExist("error", "message"));
    }

    @Test
    void testLoginPageWithError() throws Exception {
        mockMvc.perform(get("/login").param("error", ""))
                .andExpect(status().isOk())
                .andExpect(view().name("login"))
                .andExpect(model().attribute("error", "Invalid username or password!"));
    }

    @Test
    void testLoginPageWithLogout() throws Exception {
        mockMvc.perform(get("/login").param("logout", ""))
                .andExpect(status().isOk())
                .andExpect(view().name("login"))
                .andExpect(model().attribute("message", "You have been logged out successfully."));
    }

    @Test
    void testRegisterPage() throws Exception {
        mockMvc.perform(get("/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("register"))
                .andExpect(model().attributeExists("user"));
    }

    @Test
    void testRegisterUserSuccess() throws Exception {
        when(userService.existsByUsername("john")).thenReturn(false);

        mockMvc.perform(post("/register")
                        .param("username", "john")
                        .param("password", "password123")
                        .param("firstName", "John")
                        .param("lastName", "Doe")
                        .param("email", "john@example.com"))
                .andExpect(status().isOk())
                .andExpect(view().name("login"))
                .andExpect(model().attribute("success", "Registration successful! Please login."));

        verify(userService).save(any(User.class));
    }

    @Test
    void testRegisterUserUsernameExists() throws Exception {
        when(userService.existsByUsername("john")).thenReturn(true);

        mockMvc.perform(post("/register")
                        .param("username", "john")
                        .param("password", "password123")
                        .param("firstName", "John")
                        .param("lastName", "Doe")
                        .param("email", "john@example.com"))
                .andExpect(status().isOk())
                .andExpect(view().name("register"))
                .andExpect(model().attribute("error", "Username already exists!"));
    }

    @Test
    void testRegisterUserValidationFails() throws Exception {
        mockMvc.perform(post("/register")
                        .param("username", "") // Invalid: empty
                        .param("password", ""))
                .andExpect(status().isOk())
                .andExpect(view().name("register"));
    }
}
