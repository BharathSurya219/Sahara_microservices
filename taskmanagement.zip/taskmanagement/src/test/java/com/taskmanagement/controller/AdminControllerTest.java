package com.taskmanagement.controller;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.taskmanagement.entity.Project;
import com.taskmanagement.entity.Task;
import com.taskmanagement.entity.User;
import com.taskmanagement.service.ProjectService;
import com.taskmanagement.service.TaskService;
import com.taskmanagement.service.UserService;

@WebMvcTest(AdminController.class)
@WithMockUser(username = "admin", roles = {"ADMIN"}) // ✅ Bypass security
public class AdminControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ProjectService projectService;

    @MockitoBean
    private TaskService taskService;

    @MockitoBean
    private UserService userService;

    private Project project;
    private Task task;
    private User user;

    @BeforeEach
    void setup() {
        project = new Project();
        project.setId(1L);
        project.setName("Project A");

        task = new Task();
        task.setId(1L);
        task.setName("Task A");

        user = new User();
        user.setId(1L);
        user.setUsername("Alice");
    }

    @Test
    void testDashboard() throws Exception {
        when(projectService.findAll()).thenReturn(Arrays.asList(project));
        when(taskService.findAll()).thenReturn(Arrays.asList(task));
        when(taskService.countPendingTasks()).thenReturn(5L);
        when(taskService.countInProgressTasks()).thenReturn(3L);
        when(taskService.countCompletedTasks()).thenReturn(7L);

        mockMvc.perform(get("/admin/dashboard"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/dashboard"))
                .andExpect(model().attributeExists(
                        "totalProjects", "totalTasks",
                        "pendingTasks", "inProgressTasks",
                        "completedTasks", "recentTasks"));
    }

    @Test
    void testGetProjects() throws Exception {
        when(projectService.findAll()).thenReturn(Arrays.asList(project));

        mockMvc.perform(get("/admin/projects"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/projects"))
                .andExpect(model().attributeExists("projects", "project"));
    }

    @Test
    void testEditProject() throws Exception {
        when(projectService.findById(1L)).thenReturn(Optional.of(project));
        when(projectService.findAll()).thenReturn(Arrays.asList(project));

        mockMvc.perform(get("/admin/projects/edit/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/projects"))
                .andExpect(model().attributeExists("project", "projects"));
    }

    @Test
    void testDeleteProject() throws Exception {
        mockMvc.perform(get("/admin/projects/delete/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/projects"));
        verify(projectService).deleteById(1L);
    }

    @Test
    void testGetTasks() throws Exception {
        when(taskService.findAll()).thenReturn(Arrays.asList(task));
        when(projectService.findAll()).thenReturn(Arrays.asList(project));

        mockMvc.perform(get("/admin/tasks"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/tasks"))
                .andExpect(model().attributeExists("tasks", "task", "projects"));
    }

    @Test
    void testEditTask() throws Exception {
        when(taskService.findById(1L)).thenReturn(Optional.of(task));
        when(taskService.findAll()).thenReturn(Arrays.asList(task));
        when(projectService.findAll()).thenReturn(Arrays.asList(project));

        mockMvc.perform(get("/admin/tasks/edit/1"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/tasks"))
                .andExpect(model().attributeExists("task", "tasks", "projects"));
    }

    @Test
    void testDeleteTask() throws Exception {
        mockMvc.perform(get("/admin/tasks/delete/1"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/admin/tasks"));
        verify(taskService).deleteById(1L);
    }

    @Test
    void testAssignTaskForm() throws Exception {
        when(taskService.findAll()).thenReturn(Arrays.asList(task));
        when(userService.findEmployees()).thenReturn(Arrays.asList(user));

        mockMvc.perform(get("/admin/assign-task"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/assign-task"))
                .andExpect(model().attributeExists("tasks", "employees", "assignment"));
    }

}
