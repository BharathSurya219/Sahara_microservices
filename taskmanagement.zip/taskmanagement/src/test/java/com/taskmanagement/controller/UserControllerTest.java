package com.taskmanagement.controller;

import com.taskmanagement.entity.Task;
import com.taskmanagement.entity.User;
import com.taskmanagement.service.TaskService;
import com.taskmanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/user")
public class UserControllerTest {
    
    @Autowired
    private TaskService taskService;
    
    @Autowired
    private UserService userService;
    
    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        String username = authentication.getName();
        Optional<User> user = userService.findByUsername(username);
        
        if (user.isPresent()) {
            List<Task> assignedTasks = taskService.findByAssignedTo(user.get());
            model.addAttribute("tasks", assignedTasks);
            model.addAttribute("user", user.get());
        }
        
        return "user/dashboard";
    }
    
    @PostMapping("/task/update-status")
    public String updateTaskStatus(@RequestParam("taskId") Long taskId,
                                  @RequestParam("status") String status) {
        Optional<Task> task = taskService.findById(taskId);
        if (task.isPresent()) {
            Task t = task.get();
            t.setStatus(Task.Status.valueOf(status));
            taskService.save(t);
        }
        return "redirect:/user/dashboard";
    }
}
