package com.taskmanagement.service;


import com.taskmanagement.entity.Project;
import com.taskmanagement.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProjectServiceTest {
    
    @Autowired
    private ProjectRepository projectRepository;
    
    public Project save(Project project) {
        return projectRepository.save(project);
    }
    
    public List<Project> findAll() {
        return projectRepository.findAll();
    }
    
    public Optional<Project> findById(Long id) {
        return projectRepository.findById(id);
    }
    
    public void deleteById(Long id) {
        projectRepository.deleteById(id);
    }
}
