package com.taskmanagement.service;


import com.taskmanagement.entity.Task;
import com.taskmanagement.entity.User;
import com.taskmanagement.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    
    @Autowired
    private TaskRepository taskRepository;
    
    public Task save(Task task) {
        return taskRepository.save(task);
    }
    
    public List<Task> findAll() {
        return taskRepository.findAll();
    }
    
    public List<Task> findByAssignedTo(User user) {
        return taskRepository.findByAssignedTo(user);
    }
    
    public Optional<Task> findById(Long id) {
        return taskRepository.findById(id);
    }
    
    public void deleteById(Long id) {
        taskRepository.deleteById(id);
    }
    
    public long countPendingTasks() {
        return taskRepository.countPendingTasks();
    }
    
    public long countInProgressTasks() {
        return taskRepository.countInProgressTasks();
    }
    
    public long countCompletedTasks() {
        return taskRepository.countCompletedTasks();
    }
}
