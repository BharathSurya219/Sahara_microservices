package com.taskmanagement.repository;

import com.taskmanagement.entity.Task;
import com.taskmanagement.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByAssignedTo(User user);
    
    @Query("SELECT COUNT(t) FROM Task t WHERE t.status = 'PENDING'")
    long countPendingTasks();
    
    @Query("SELECT COUNT(t) FROM Task t WHERE t.status = 'IN_PROGRESS'")
    long countInProgressTasks();
    
    @Query("SELECT COUNT(t) FROM Task t WHERE t.status = 'COMPLETED'")
    long countCompletedTasks();
}
