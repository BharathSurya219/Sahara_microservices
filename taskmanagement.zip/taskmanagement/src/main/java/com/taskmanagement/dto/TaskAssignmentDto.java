package com.taskmanagement.dto;

import lombok.Data;

@Data
public class TaskAssignmentDto {

	private Long taskId;
    private Long userId;
    
}
