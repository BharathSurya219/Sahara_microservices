package com.taskmanagement.controller;

import com.taskmanagement.entity.Project;
import com.taskmanagement.entity.Task;
import com.taskmanagement.entity.User;
import com.taskmanagement.dto.TaskAssignmentDto;
import com.taskmanagement.service.ProjectService;
import com.taskmanagement.service.TaskService;
import com.taskmanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class AdminController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private ProjectService projectService;
    
    @Autowired
    private TaskService taskService;
    
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("totalProjects", projectService.findAll().size());
        model.addAttribute("totalTasks", taskService.findAll().size());
        model.addAttribute("pendingTasks", taskService.countPendingTasks());
        model.addAttribute("inProgressTasks", taskService.countInProgressTasks());
        model.addAttribute("completedTasks", taskService.countCompletedTasks());
        model.addAttribute("recentTasks", taskService.findAll());
        return "admin/dashboard";
    }
    
    // Project Management
    @GetMapping("/projects")
    public String projects(Model model) {
        model.addAttribute("projects", projectService.findAll());
        model.addAttribute("project", new Project());
        return "admin/projects";
    }
    
    @PostMapping("/projects")
    public String addProject(@Valid @ModelAttribute("project") Project project,
                           BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("projects", projectService.findAll());
            return "admin/projects";
        }
        projectService.save(project);
        return "redirect:/admin/projects";
    }
    
    @GetMapping("/projects/edit/{id}")
    public String editProject(@PathVariable Long id, Model model) {
        Optional<Project> project = projectService.findById(id);
        if (project.isPresent()) {
            model.addAttribute("project", project.get());
            model.addAttribute("projects", projectService.findAll());
            return "admin/projects";
        }
        return "redirect:/admin/projects";
    }
    
    @GetMapping("/projects/delete/{id}")
    public String deleteProject(@PathVariable Long id) {
        projectService.deleteById(id);
        return "redirect:/admin/projects";
    }
    
    // Task Management
    @GetMapping("/tasks")
    public String tasks(Model model) {
        model.addAttribute("tasks", taskService.findAll());
        model.addAttribute("task", new Task());
        model.addAttribute("projects", projectService.findAll());
        return "admin/tasks";
    }
    
    @PostMapping("/tasks")
    public String addTask(@Valid @ModelAttribute("task") Task task,
                         @RequestParam("projectId") Long projectId,
                         BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("tasks", taskService.findAll());
            model.addAttribute("projects", projectService.findAll());
            return "admin/tasks";
        }
        Optional<Project> project = projectService.findById(projectId);
        if (project.isPresent()) {
            task.setProject(project.get());
            taskService.save(task);
        }
        return "redirect:/admin/tasks";
    }
    
    @GetMapping("/tasks/edit/{id}")
    public String editTask(@PathVariable Long id, Model model) {
        Optional<Task> task = taskService.findById(id);
        if (task.isPresent()) {
            model.addAttribute("task", task.get());
            model.addAttribute("tasks", taskService.findAll());
            model.addAttribute("projects", projectService.findAll());
            return "admin/tasks";
        }
        return "redirect:/admin/tasks";
    }
    
    @GetMapping("/tasks/delete/{id}")
    public String deleteTask(@PathVariable Long id) {
        taskService.deleteById(id);
        return "redirect:/admin/tasks";
    }
    
    // Task Assignment
    @GetMapping("/assign-task")
    public String assignTask(Model model) {
        model.addAttribute("tasks", taskService.findAll());
        model.addAttribute("employees", userService.findEmployees());
        model.addAttribute("assignment", new TaskAssignmentDto());
        return "admin/assign-task";
    }
    
    @PostMapping("/assign-task")
    public String assignTask(@ModelAttribute("assignment") TaskAssignmentDto assignment) {
        Optional<Task> task = taskService.findById(assignment.getTaskId());
        Optional<User> user = userService.findById(assignment.getUserId());
        
        if (task.isPresent() && user.isPresent()) {
            Task t = task.get();
            t.setAssignedTo(user.get());
            taskService.save(t);
        }
        return "redirect:/admin/assign-task";
    }
}
